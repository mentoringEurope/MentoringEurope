package Tahir.mentoring2;

public class Main {
    public static void main(String[] args) {

        /*

         // equals method
        // contains
        //length
        // substring

        //charAt
        // indexOf
        //replace

         */

    }


}
