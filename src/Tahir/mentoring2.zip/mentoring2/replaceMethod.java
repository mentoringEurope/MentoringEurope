package Tahir.mentoring2;

public class replaceMethod {

    public static void main(String[] args) {


    }
}
