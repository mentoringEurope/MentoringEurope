package Tahir.mentoring2;

public class OkulProjesi {
}
