package Tahir.mentoring2;

public class ifCondition {
    public static void main(String[] args) {


        if(true){
            System.out.println("it is OK");
        }



        if(false){
            System.out.println("it is not OK");
        }








    }
}
