package Tahir.treeMaps;

public class TreeMap_4 {
    // TreeMap_3 ornegini method kullanarak yapin.parametre String olsun
}
